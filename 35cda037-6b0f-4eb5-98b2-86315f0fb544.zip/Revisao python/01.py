class Pessoa:
    def __init__(self, nome, idade, profissao):
        self.nome = nome
        self.idade = idade
        self.profissao = profissao
    
    def apresentar(self):
        print(f"Olá, meu nome é {self.nome}, tenho {self.idade} anos e sou {self.profissao}.")

nome1 = input("Digite o nome da primeira pessoa: ")
idade1 = int(input("Digite a idade da primeira pessoa: "))
profissao1 = input("Digite a profissão da primeira pessoa: ")
pessoa1 = Pessoa(nome1, idade1, profissao1)

nome2 = input("\nDigite o nome da segunda pessoa: ")
idade2 = int(input("Digite a idade da segunda pessoa: "))
profissao2 = input("Digite a profissão da segunda pessoa: ")
pessoa2 = Pessoa(nome2, idade2, profissao2)

print("\n Apresentação das Pessoas ")
pessoa1.apresentar()
pessoa2.apresentar()