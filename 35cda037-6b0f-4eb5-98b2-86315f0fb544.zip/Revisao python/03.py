class Produto:
    def __init__(self, nome, preco, estoque):
        self.nome = nome
        self.preco = preco
        self.estoque = estoque
    
    def vender(self, qtd):
        if self.estoque >= qtd:
            self.estoque -= qtd
            print(f"{qtd} unidades de {self.nome} vendidas. Estoque atual: {self.estoque}")
        else:
            print(f"Estoque insuficiente. Disponível: {self.estoque} unidades.")
    
    def repor(self, qtd):
        self.estoque += qtd
        print(f"{qtd} unidades de {self.nome} repostas. Estoque atual: {self.estoque}")

nome_prod = input("Digite o nome do produto: ")
preco_prod = float(input("Digite o preço do produto: R$ "))
estoque_prod = int(input("Digite a quantidade inicial em estoque: "))
produto = Produto(nome_prod, preco_prod, estoque_prod)

print(f"\n Gerenciamento de {produto.nome} ")
vender_qtd = int(input("Quantas unidades você quer vender? "))
produto.vender(vender_qtd)

repor_qtd = int(input("Quantas unidades você quer repor? "))
produto.repor(repor_qtd)