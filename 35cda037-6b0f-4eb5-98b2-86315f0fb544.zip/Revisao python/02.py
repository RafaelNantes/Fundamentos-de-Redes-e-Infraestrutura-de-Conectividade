class ContaBancaria:
    def __init__(self, titular, saldo=0):
        self.titular = titular
        self.saldo = saldo
    
    def depositar(self, valor):
        self.saldo += valor
        print(f"Depósito de R$ {valor:.2f} realizado. Saldo atual: R$ {self.saldo:.2f}")
    
    def sacar(self, valor):
        if self.saldo >= valor:
            self.saldo -= valor
            print(f"Saque de R$ {valor:.2f} realizado. Saldo atual: R$ {self.saldo:.2f}")
        else:
            print("Saldo insuficiente.")

titular = input("Digite o nome do titular da conta: ")
saldo_inicial = float(input("Digite o saldo inicial: R$ "))
conta = ContaBancaria(titular, saldo_inicial)

valor_deposito = float(input("\nDigite o valor para depósito: R$ "))
conta.depositar(valor_deposito)

valor_saque = float(input("Digite o valor para saque: R$ "))
conta.sacar(valor_saque)