class Aluno:
    def __init__(self, nome, curso, tempoSemDormir=0):
        self.nome = nome
        self.curso = curso
        self.tempoSemDormir = tempoSemDormir

    def estudar(self, horas_de_estudo):
        self.tempoSemDormir += horas_de_estudo
        print(f"{self.nome} estudou por {horas_de_estudo} horas.")

    def dormir(self, horas_de_sono):
        self.tempoSemDormir = max(0, self.tempoSemDormir - horas_de_sono)
        print(f"{self.nome} dormiu por {horas_de_sono} horas.")

nome_aluno = input("Digite o nome do aluno: ")
curso_aluno = input("Digite o nome do curso: ")
aluno_teste = Aluno(nome_aluno, curso_aluno)

print(f"\nTempo inicial sem dormir de {aluno_teste.nome}: {aluno_teste.tempoSemDormir} horas.")

horas_estudo = float(input("\nQuantas horas o aluno estudou? "))
aluno_teste.estudar(horas_estudo)
print(f"Tempo sem dormir após estudar: {aluno_teste.tempoSemDormir} horas.")

horas_sono = float(input("Quantas horas o aluno dormiu? "))
aluno_teste.dormir(horas_sono)
print(f"Tempo sem dormir após dormir: {aluno_teste.tempoSemDormir} horas.")