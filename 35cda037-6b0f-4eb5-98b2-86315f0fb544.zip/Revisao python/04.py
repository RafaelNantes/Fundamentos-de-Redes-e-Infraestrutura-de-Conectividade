class Carro:
    def __init__(self, marca, cor, placa):
        self.marca = marca
        self.cor = cor
        self.placa = placa
        self.velocidade_atual = 0
        self.marcha_atual = 'N'
        self.freio_de_mao_puxado = True
        self.chave_virada = False

    def ligar(self):
        if not self.chave_virada:
            self.chave_virada = True
            print(f"O carro de placa {self.placa} foi ligado.")
        else:
            print(f"O carro de placa {self.placa} já está ligado.")

    def acelerar_ate(self, velocidade):
        if self.chave_virada and not self.freio_de_mao_puxado:
            self.velocidade_atual = velocidade
            print(f"Acelerando... Velocidade atual: {self.velocidade_atual} km/h.")
        else:
            print("Não é possível acelerar. O carro está desligado ou com o freio de mão puxado.")

    def mudar_marcha(self, marcha):
        if self.chave_virada:
            self.marcha_atual = marcha
            print(f"Marcha alterada para: {self.marcha_atual}.")
        else:
            print("Não é possível mudar a marcha. O carro está desligado.")

    def parar(self):
        self.velocidade_atual = 0
        self.marcha_atual = 'N'
        self.freio_de_mao_puxado = True
        print(f"O carro de placa {self.placa} parou. Freio de mão puxado.")

num_carros = int(input("Quantos carros você deseja criar (máximo 10)? "))
num_carros = min(num_carros, 10)

carros = []
for i in range(num_carros):
    print(f"\n Dados do Carro {i+1} ")
    marca = input("Marca: ")
    cor = input("Cor: ")
    placa = input("Placa: ")
    carros.append(Carro(marca, cor, placa))

for i, carro in enumerate(carros):
    print(f"\n--- Testando Carro {i+1} ({carro.placa}) ---")
    carro.ligar()
    carro.mudar_marcha(input("Digite a marcha para engatar (ex: D, R, 1, 2): "))
    velocidade = int(input("Digite a velocidade para acelerar: "))
    carro.acelerar_ate(velocidade)
    carro.parar()