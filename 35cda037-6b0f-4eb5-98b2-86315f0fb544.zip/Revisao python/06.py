class Funcionario:
    def __init__(self, nome, salario):
        self.nome = nome
        self.salario = salario

    def aumentarSalario(self, porcentual_de_aumento):
        aumento = self.salario * (porcentual_de_aumento / 100)
        self.salario += aumento
        print(f"Salário de {self.nome} aumentado em {porcentual_de_aumento}%.")
        print(f"Novo salário: R$ {self.salario:.2f}")

nome_func = input("Digite o nome do funcionário: ")
salario_func = float(input("Digite o salário inicial: R$ "))
funcionario_teste = Funcionario(nome_func, salario_func)

print(f"\nSalário inicial de {funcionario_teste.nome}: R$ {funcionario_teste.salario:.2f}")

aumento = float(input("Digite o percentual de aumento: "))
funcionario_teste.aumentarSalario(aumento)