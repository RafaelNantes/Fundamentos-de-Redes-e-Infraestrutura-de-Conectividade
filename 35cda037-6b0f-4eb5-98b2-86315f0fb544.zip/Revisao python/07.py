class Livro:
    def __init__(self, nome, qtdPaginas, autor, preco):
        self.nome = nome
        self.qtdPaginas = qtdPaginas
        self.autor = autor
        self.preco = preco

    def getPreco(self):
        return self.preco

    def setPreco(self, novo_preco):
        if novo_preco > 0:
            self.preco = novo_preco
            print(f"Preço do livro '{self.nome}' alterado para R$ {self.preco:.2f}")
        else:
            print("Preço inválido. O valor deve ser positivo.")

nome_livro = input("Digite o nome do livro: ")
qtd_paginas = int(input("Digite a quantidade de páginas: "))
autor_livro = input("Digite o nome do autor: ")
preco_inicial = float(input("Digite o preço inicial: R$ "))

livro = Livro(nome_livro, qtd_paginas, autor_livro, preco_inicial)

print(f"\nO preço inicial do livro '{livro.nome}' é R$ {livro.getPreco():.2f}")

novo_preco = float(input("\nDigite o novo preço para o livro: R$ "))
livro.setPreco(novo_preco)