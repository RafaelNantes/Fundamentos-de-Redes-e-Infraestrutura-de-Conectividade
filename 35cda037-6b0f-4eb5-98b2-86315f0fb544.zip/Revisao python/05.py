class Triangulo:
    def __init__(self, ladoA, ladoB, ladoC):
        self.ladoA = ladoA
        self.ladoB = ladoB
        self.ladoC = ladoC

    def calcular_perimetro(self):
        return self.ladoA + self.ladoB + self.ladoC

    def get_maior_lado(self):
        return max(self.ladoA, self.ladoB, self.ladoC)

try:
    ladoA = float(input("Digite a medida do lado A do triângulo: "))
    ladoB = float(input("Digite a medida do lado B do triângulo: "))
    ladoC = float(input("Digite a medida do lado C do triângulo: "))
    
    triangulo_usuario = Triangulo(ladoA, ladoB, ladoC)
    
    perimetro = triangulo_usuario.calcular_perimetro()
    maior_lado = triangulo_usuario.get_maior_lado()
    
    print(f"\nO perímetro do triângulo é: {perimetro}")
    print(f"O maior lado do triângulo é: {maior_lado}")

except ValueError:
    print("Entrada inválida. Por favor, digite valores numéricos para os lados.")